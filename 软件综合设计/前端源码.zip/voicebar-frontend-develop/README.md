# voicebar_frontend

## 初次使用以及添加新插件包后
```
在目录下执行npm install
```

### Compiles and hot-reloads for development(在本地开发调试)
```
npm run serve
```

### Compiles and minifies for production(打包成静态文件,在dist文件夹里面)
```
npm run build
```

### 不要多人同时修改同一文件,同一处代码,防止冲突

在无冲突的情况下合并提交

### Customize configuration

See [Configuration Reference](https://cli.vuejs.org/config/).
