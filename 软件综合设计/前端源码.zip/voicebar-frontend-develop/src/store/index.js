import { createStore } from 'vuex'

//没有在项目中使用

export default createStore({
  state: {
  },
  getters: {
  },
  mutations: {
  },
  actions: {
  },
  modules: {
  }
})
