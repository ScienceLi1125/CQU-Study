import numpy as np

class LogisticRegression(object):
    def __init__(self,learning_rate=0.01,num_iterations=1000,batch_size=10,threshold=0.5):
        self.learning_rate = learning_rate
        self.num_iterations = num_iterations
        self.batch_size = batch_size
        self.threshold = threshold
        self.weights = None
        self.bias = None
    
    def sigmod(self,z):
        return 1/(1+np.exp(z))
    
    def softmax(self,z): # 二维的softmax其实就是sigmod
        return np.exp(z)/np.sum(np.exp(z),axis=1,keepdims=True)
    
    def fit_with_gd(self,X:np.array,y:np.array) -> 'LogisticRegression':
        num_samples ,num_features = X.shape
        num_classes = int(len(np.unique(y)))
        # init W,b
        self.weights = np.random.randn(num_features,num_classes)
        self.bias = np.zeros(num_classes)
        y = np.eye(num_classes)[y]
        # GD
        for i in range(self.num_iterations):
            # 广播机制
            z = np.dot(X,self.weights)+self.bias
            y_pred = self.softmax(z)
            
            # cost其实是负对数似然的平均值
            
            # cost = (-1/num_samples) * np.sum(y * np.log(y_pred))
            dw = (1/num_samples) * np.dot(X.T, (y_pred - y))
            db = (1/num_samples) * np.sum(y_pred - y, axis=0)

            self.weights -= self.learning_rate * dw
            self.bias -= self.learning_rate * db

        return self

    def fit_with_sgd(self,X:np.array,y:np.array) -> "LogisticRegression":
        num_samples ,num_features = X.shape
        num_classes = int(len(np.unique(y)))
        # init W,b
        self.weights = np.zeros((num_features,num_classes))
        self.bias = np.zeros(num_classes)
        y = np.eye(num_classes)[y]

         # 小批量随机梯度下降算法
        for i in range(self.num_iterations):
            # 随机打乱数据集
            permutation = np.random.permutation(num_samples)
            X = X[permutation]
            y = y[permutation]
            
            # 遍历每个小批量
            for j in range(0, num_samples,self.batch_size):
                # 选择当前小批量
                X_i = X[j:j+self.batch_size]
                y_i = y[j:j+self.batch_size]
                
                # 计算模型预测值
                z = np.dot(X_i, self.weights) + self.bias
                y_pred = self.softmax(z)
                
                # 计算成本函数和梯度
                # cost = (-1/self.batch_size) * np.sum(y_i * np.log(y_pred))
                dw = (1/self.batch_size) * np.dot(X_i.T, (y_pred - y_i))
                db = (1/self.batch_size) * np.sum(y_pred - y_i, axis=0)
                
                # 更新参数
                self.weights -= self.learning_rate * dw
                self.bias -= self.learning_rate * db
        
            return self






    
    def predict(self, X: np.array) -> np.array:
        '''
        当X为(n,num_feature)的时候，输出的y_pred是(n)
        '''
        # 预测值
        z = np.dot(X, self.weights) + self.bias
        y_pred = self.softmax(z)
        
        # 将预测值转化成二分类问题的结果
        return np.argmax(y_pred,axis=1)